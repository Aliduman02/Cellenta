package com.cellenta.util;

public class DummyDataService {
}
