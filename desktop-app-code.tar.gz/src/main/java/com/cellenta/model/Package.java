package com.cellenta.model;

public class Package {
    private int amountData;
    private int amountSms;
    private int amountMinutes;
    private String startDate;
    private String endDate;

    // getter / setter / constructor / toString vs.
}
