package com.cellenta.model;

public class User {
    private String name;
    private String surname;
    private String msisdn;
    private String email;
    private String password;
    private String tcNumber;
    private String packageName;

    // getter / setter / constructor / toString vs.
}
